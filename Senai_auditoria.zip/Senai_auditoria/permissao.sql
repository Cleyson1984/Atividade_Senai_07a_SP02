use clinica_medica;

select * from paciente;

select * from paciente where nome_plano = 'Inovamed';